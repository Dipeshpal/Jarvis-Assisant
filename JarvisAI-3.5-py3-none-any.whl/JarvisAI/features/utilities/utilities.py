

def set_timer():
    # WIP
    pass
